require 'rails_helper'

RSpec.describe Product, type: :model do
  it "is valid with valid attributes" do
    category = create(:category)
    product = build(:product, category: category)
    expect(product).to be_valid
  end

  it "is not valid without a name" do
    product = build(:product, name: nil)
    expect(product).not_to be_valid
  end
end