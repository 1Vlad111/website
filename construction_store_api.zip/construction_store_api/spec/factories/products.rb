FactoryBot.define do
    factory :product do
      name { "Кабель" }
      price { 25.0 }
      association :category
    end
  end  