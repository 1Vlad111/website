FactoryBot.define do
    factory :category do
      name { "Кабельна продукція" }
    end
  end
  