require 'swagger_helper'

RSpec.describe 'api/v1/products', type: :request do
  path '/api/v1/products' do
    get('list products') do
      tags 'Products'
      produces 'application/json'

      response(200, 'successful') do
        run_test!
      end
    end

    post('create product') do
        tags 'Products'
        consumes 'application/json'
        parameter name: :product, in: :body, schema: {
          type: :object,
          properties: {
            name: { type: :string },
            price: { type: :number },
            category_id: { type: :integer }
          },
          required: ['name', 'price', 'category_id']
        }
  
        response(201, 'created') do
          let!(:category) { Category.create!(name: 'Тестова категорія') }
  
          let(:product) { { name: 'Кабель', price: 50.0, category_id: category.id } }
  
          run_test!
        end
      end
  end

  path '/api/v1/products/{id}' do
    delete('delete product') do
      tags 'Products'
      produces 'application/json'
      parameter name: :id, in: :path, type: :integer, description: 'Product ID'
  
      response(204, 'no content') do
        let(:category) { Category.create(name: 'Інструменти') }
        let(:id) { Product.create(name: 'Шурупи', price: 10.0, category_id: category.id).id }
        run_test!
      end
    end
  end  
end