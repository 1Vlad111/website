require 'rails_helper'

RSpec.describe "Products API", type: :request do
  describe "GET /api/v1/products" do
    it "returns a list of products" do
      create_list(:product, 3)
      get "/api/v1/products"
      expect(response).to have_http_status(:success)
      expect(JSON.parse(response.body).size).to eq(3)
    end
  end
end