# This file should ensure the existence of records required to run the application in every environment (production,
# development, test). The code here should be idempotent so that it can be executed at any point in every environment.
# The data can then be loaded with the bin/rails db:seed command (or created alongside the database with db:setup).
#
# Example:
#
#   ["Action", "Comedy", "Drama", "Horror"].each do |genre_name|
#     MovieGenre.find_or_create_by!(name: genre_name)
#   end
categories = [
  { name: "Будівельні матеріали", description: "Основні матеріали для зведення конструкцій" },
  { name: "Інструменти", description: "Ручний та електроінструмент" },
  { name: "Фарби та оздоблення", description: "Матеріали для внутрішнього та зовнішнього оздоблення" },
  { name: "Сантехніка", description: "Все для водопостачання та каналізації" },
  { name: "Електрика", description: "Проводка, освітлення, автоматика" },
  { name: "Двері та вікна", description: "Металопластикові конструкції та фурнітура" }
]

categories.each do |cat|
  Category.create!(cat)
end

products_data = {
  "Будівельні матеріали" => [
    ["Цемент М500", "Цемент високої міцності", "Dyckerhoff", 155.00],
    ["Пісок будівельний", "Річковий пісок для бетону", "Кар’єрбуд", 120.00],
    ["Щебінь фракція 5-20", "Гранітний щебінь", "БудІнвест", 145.00],
    ["Газоблок 600х200х300", "Теплоізоляційний блок", "Aeroc", 89.00],
    ["Арматура Ø12 мм", "Металева арматура для залізобетону", "МеталПром", 46.00]
  ],

  "Інструменти" => [
    ["Перфоратор Bosch GBH 2-26", "Професійний перфоратор", "Bosch", 3190.00],
    ["Шуруповерт Makita", "Акумуляторний шуруповерт", "Makita", 2750.00],
    ["Набір викруток", "12 предметів", "Stanley", 450.00],
    ["Рівень 60 см", "Алюмінієвий рівень", "Kapro", 280.00],
    ["Молоток слюсарний", "500 г", "Truper", 190.00]
  ],

  "Фарби та оздоблення" => [
    ["Фарба акрилова біла", "Для внутрішніх робіт", "Sniezka", 399.00],
    ["Шпаклівка фінішна", "25 кг", "Ceresit", 310.00],
    ["Грунтовка універсальна", "10 л", "Kreisel", 295.00],
    ["Валик з ручкою", "25 см", "Anza", 120.00],
    ["Пензель плоский", "70 мм", "Dekor", 85.00]
  ],

  "Сантехніка" => [
    ["Умивальник Cersanit", "50 см, білий", "Cersanit", 740.00],
    ["Кран кухонний", "З гусаком", "Vidima", 1150.00],
    ["Поліпропіленова труба Ø20", "3 метри", "FV Plast", 95.00],
    ["Сифон для мийки", "Пластиковий", "AlcaPlast", 155.00],
    ["Змішувач для душу", "Настінний", "Grohe", 1890.00]
  ],

  "Електрика" => [
    ["Кабель ВВГнг 3x2.5", "100 м", "Odessa Cable", 1480.00],
    ["Розетка подвійна", "З заземленням", "Legrand", 210.00],
    ["Вимикач одноклавішний", "Білий", "Schneider", 130.00],
    ["Автоматичний вимикач 16А", "Однополюсний", "ABB", 160.00],
    ["Світильник LED 18Вт", "Стельовий", "Philips", 320.00]
  ],

  "Двері та вікна" => [
    ["Двері міжкімнатні", "800х2000, дуб", "Оміс", 2350.00],
    ["Ручка дверна", "Нікель", "Apolo", 210.00],
    ["Петлі дверні", "Комплект 2 шт", "Armstrong", 90.00],
    ["Вікно ПВХ 1200х1400", "2-камерне", "Steko", 3450.00],
    ["Підвіконня пластикове", "150 мм, біле", "Danke", 175.00]
  ]
}

products_data.each do |category_name, products|
  category = Category.find_by(name: category_name)
  products.each do |name, description, brand, price|
    Product.create!(
      name: name,
      description: description,
      category_id: category.id,
      brand: brand,
      price: price,
      quantity: 100,
      image_url: "",
    )
  end
end
