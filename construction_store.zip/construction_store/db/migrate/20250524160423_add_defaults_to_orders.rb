class AddDefaultsToOrders < ActiveRecord::Migration[7.2]
  def change
    change_column_default :orders, :status, 'очікує_обробки'
    change_column_default :orders, :total_price, 0.0
  end
end
