class CreateAdminsActionsLogs < ActiveRecord::Migration[7.2]
  def change
    create_table :admins_actions_logs do |t|
      t.integer :admin_id
      t.text :action
      t.datetime :timestamp

      t.timestamps
    end
  end
end
