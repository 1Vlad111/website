class Order < ApplicationRecord
    has_many :order_items, dependent: :destroy
    has_many :products, through: :order_items
    belongs_to :user

    enum status: {
    очікує_обробки: 'очікує_обробки',
    підтверджено: 'підтверджено',
    скасовано: 'скасовано'
  }

  def total_price
    order_items.sum("quantity * price")
  end
end
