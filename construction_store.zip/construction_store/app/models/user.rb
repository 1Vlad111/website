class User < ApplicationRecord
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable, :trackable and :omniauthable
  has_many :cart_items, dependent: :destroy
  has_many :orders, dependent: :destroy
  
  validates :email, presence: true
  validates :role, presence: true

  enum role: { user: 'user', admin: 'admin' }
  enum status: { active: 'active', inactive: 'inactive' }

  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :validatable
end
