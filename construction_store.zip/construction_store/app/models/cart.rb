class Cart < ApplicationRecord
end
