class Product < ApplicationRecord
    validates :name, presence: true, uniqueness: true
    validates :price, numericality: { greater_than: 0 } 

    has_many :cart_items
    belongs_to :category
    has_many :order_items
    has_many :orders, through: :order_items
end