class AdminsActionsLog < ApplicationRecord
end
