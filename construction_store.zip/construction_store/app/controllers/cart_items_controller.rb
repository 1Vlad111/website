class CartItemsController < ApplicationController
    before_action :authenticate_user!
  
    def create
        product = Product.find(params[:product_id])
        item = current_user.cart_items.find_by(product_id: product.id)
      
        if item
          item.quantity ||= 0  # на випадок, якщо чомусь quantity = nil
          item.quantity += 1
        else
          item = current_user.cart_items.build(product: product, quantity: 1)
        end
      
        if item.save
            redirect_to category_product_path(product.category, product), notice: "Товар додано до кошика."
        else
            redirect_to category_product_path(product.category, product), alert: "Не вдалося додати товар до кошика."
        end
      end      
  
    def destroy
      item = current_user.cart_items.find(params[:id])
      item.destroy
      redirect_to cart_path
    end
  end
  