class AdminsActionsLogsController < ApplicationController
  before_action :set_admins_actions_log, only: %i[ show edit update destroy ]

  # GET /admins_actions_logs or /admins_actions_logs.json
  def index
    @admins_actions_logs = AdminsActionsLog.all
  end

  # GET /admins_actions_logs/1 or /admins_actions_logs/1.json
  def show
  end

  # GET /admins_actions_logs/new
  def new
    @admins_actions_log = AdminsActionsLog.new
  end

  # GET /admins_actions_logs/1/edit
  def edit
  end

  # POST /admins_actions_logs or /admins_actions_logs.json
  def create
    @admins_actions_log = AdminsActionsLog.new(admins_actions_log_params)

    respond_to do |format|
      if @admins_actions_log.save
        format.html { redirect_to @admins_actions_log, notice: "Admins actions log was successfully created." }
        format.json { render :show, status: :created, location: @admins_actions_log }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @admins_actions_log.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /admins_actions_logs/1 or /admins_actions_logs/1.json
  def update
    respond_to do |format|
      if @admins_actions_log.update(admins_actions_log_params)
        format.html { redirect_to @admins_actions_log, notice: "Admins actions log was successfully updated." }
        format.json { render :show, status: :ok, location: @admins_actions_log }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @admins_actions_log.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /admins_actions_logs/1 or /admins_actions_logs/1.json
  def destroy
    @admins_actions_log.destroy!

    respond_to do |format|
      format.html { redirect_to admins_actions_logs_path, status: :see_other, notice: "Admins actions log was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_admins_actions_log
      @admins_actions_log = AdminsActionsLog.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def admins_actions_log_params
      params.require(:admins_actions_log).permit(:admin_id, :action, :timestamp)
    end
end
