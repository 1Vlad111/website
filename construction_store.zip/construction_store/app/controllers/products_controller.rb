class ProductsController < ApplicationController
  before_action :authenticate_user!
  before_action :authorize_admin!, only: [:new, :create, :edit, :update, :destroy]
before_action :set_product, only: %i[show edit update destroy]



  # GET /products or /products.json
  def index
    if params[:category_id]
      @category = Category.find(params[:category_id])
      @products = @category.products
    else
      @products = Product.all
    end
  end  

  # GET /products/1 or /products/1.json
  def show
    @category = Category.find(params[:category_id])
    @product = @category.products.find(params[:id])
  end  

  # GET /products/new
  def new
    @product = Product.new
  end

  # GET /products/1/edit
  def edit
  end

  # POST /products or /products.json
  def create
    @product = Product.new(product_params)

    respond_to do |format|
      if @product.save
        format.html { redirect_to @product, notice: "Product was successfully created." }
        format.json { render :show, status: :created, location: @product }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @product.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /products/1 or /products/1.json
  def update
    respond_to do |format|
      if @product.update(product_params)
        format.html { redirect_to @product, notice: "Product was successfully updated." }
        format.json { render :show, status: :ok, location: @product }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @product.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /products/1 or /products/1.json
  def destroy
    @product.destroy

    respond_to do |format|
      format.html { redirect_to category_products_path(@product.category), notice: 'Продукт видалено.'    }
      format.json { head :no_content }
    end
  end

  def all
    @products = Product.includes(:category)
  
    if params[:name].present?
      @products = @products.where("name ILIKE ?", "%#{params[:name]}%")
    end
  
    if params[:category_id].present?
      @products = @products.where(category_id: params[:category_id])
    end
  
    if params[:brand].present?
      @products = @products.where("brand ILIKE ?", "%#{params[:brand]}%")
    end
  
    if params[:min_price].present?
      @products = @products.where("price >= ?", params[:min_price].to_f)
    end
  
    if params[:max_price].present?
      @products = @products.where("price <= ?", params[:max_price].to_f)
    end
  end    

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_product
      if params[:category_id]
        @product = Product.find_by(id: params[:id], category_id: params[:category_id])
      else
        @product = Product.find(params[:id])
      end
    end    

    # Only allow a list of trusted parameters through.
    def product_params
      params.require(:product).permit(:name, :description, :category_id, :brand, :price, :quantity, :image_url)
    end

    def authorize_admin!
      redirect_to root_path, alert: 'Доступ заборонено' unless current_user.admin?
    end
end
