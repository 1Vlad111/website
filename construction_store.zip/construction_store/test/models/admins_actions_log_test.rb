require "test_helper"

class AdminsActionsLogTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
