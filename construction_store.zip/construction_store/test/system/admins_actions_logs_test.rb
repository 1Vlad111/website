require "application_system_test_case"

class AdminsActionsLogsTest < ApplicationSystemTestCase
  setup do
    @admins_actions_log = admins_actions_logs(:one)
  end

  test "visiting the index" do
    visit admins_actions_logs_url
    assert_selector "h1", text: "Admins actions logs"
  end

  test "should create admins actions log" do
    visit admins_actions_logs_url
    click_on "New admins actions log"

    fill_in "Action", with: @admins_actions_log.action
    fill_in "Admin", with: @admins_actions_log.admin_id
    fill_in "Timestamp", with: @admins_actions_log.timestamp
    click_on "Create Admins actions log"

    assert_text "Admins actions log was successfully created"
    click_on "Back"
  end

  test "should update Admins actions log" do
    visit admins_actions_log_url(@admins_actions_log)
    click_on "Edit this admins actions log", match: :first

    fill_in "Action", with: @admins_actions_log.action
    fill_in "Admin", with: @admins_actions_log.admin_id
    fill_in "Timestamp", with: @admins_actions_log.timestamp.to_s
    click_on "Update Admins actions log"

    assert_text "Admins actions log was successfully updated"
    click_on "Back"
  end

  test "should destroy Admins actions log" do
    visit admins_actions_log_url(@admins_actions_log)
    click_on "Destroy this admins actions log", match: :first

    assert_text "Admins actions log was successfully destroyed"
  end
end
