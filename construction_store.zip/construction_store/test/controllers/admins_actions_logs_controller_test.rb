require "test_helper"

class AdminsActionsLogsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @admins_actions_log = admins_actions_logs(:one)
  end

  test "should get index" do
    get admins_actions_logs_url
    assert_response :success
  end

  test "should get new" do
    get new_admins_actions_log_url
    assert_response :success
  end

  test "should create admins_actions_log" do
    assert_difference("AdminsActionsLog.count") do
      post admins_actions_logs_url, params: { admins_actions_log: { action: @admins_actions_log.action, admin_id: @admins_actions_log.admin_id, timestamp: @admins_actions_log.timestamp } }
    end

    assert_redirected_to admins_actions_log_url(AdminsActionsLog.last)
  end

  test "should show admins_actions_log" do
    get admins_actions_log_url(@admins_actions_log)
    assert_response :success
  end

  test "should get edit" do
    get edit_admins_actions_log_url(@admins_actions_log)
    assert_response :success
  end

  test "should update admins_actions_log" do
    patch admins_actions_log_url(@admins_actions_log), params: { admins_actions_log: { action: @admins_actions_log.action, admin_id: @admins_actions_log.admin_id, timestamp: @admins_actions_log.timestamp } }
    assert_redirected_to admins_actions_log_url(@admins_actions_log)
  end

  test "should destroy admins_actions_log" do
    assert_difference("AdminsActionsLog.count", -1) do
      delete admins_actions_log_url(@admins_actions_log)
    end

    assert_redirected_to admins_actions_logs_url
  end
end
