import "bootstrap";
import "@hotwired/turbo-rails"
import "controllers"
import "@rails/ujs"

Rails.start();
